# -*- coding: utf-8 -*-
import unittest

import numpy as np
from equistore import Labels

from rascaline import RascalError, SortedDistances
from rascaline.calculators import DummyCalculator

from test_systems import TestSystem


class TestDummyCalculator(unittest.TestCase):
    def test_name(self):
        calculator = DummyCalculator(cutoff=3.2, delta=12, name="foo", gradients=True)
        self.assertEqual(
            calculator.name,
            "dummy test calculator with cutoff: 3.2 - delta: 12"
            " - name: foo - gradients: true",
        )

        self.assertEqual(calculator.c_name, "dummy_calculator")

        # very long name, checking that we can pass large string back and forth
        name = "abc" * 2048
        calculator = DummyCalculator(cutoff=3.2, delta=12, name=name, gradients=True)
        self.assertEqual(
            calculator.name,
            "dummy test calculator with cutoff: 3.2 - delta: 12"
            f" - name: {name} - gradients: true",
        )

    def test_parameters(self):
        calculator = DummyCalculator(cutoff=3.2, delta=12, name="foo", gradients=True)
        self.assertEqual(
            calculator.parameters,
            """{"cutoff": 3.2, "delta": 12, "name": "foo", "gradients": true}""",
        )

    def test_bad_parameters(self):
        message = (
            'json error: invalid type: string "12", expected isize at line 1 column 29'
        )

        with self.assertRaisesRegex(Exception, message):
            _ = DummyCalculator(cutoff=3.2, delta="12", name="foo", gradients=True)

    def test_compute(self):
        system = TestSystem()
        calculator = DummyCalculator(cutoff=3.2, delta=2, name="", gradients=True)
        descriptor = calculator.compute(system, use_native_system=False)

        self.assertEqual(len(descriptor.keys), 2)
        self.assertEqual(descriptor.keys.names, ("species_center",))
        self.assertEqual(tuple(descriptor.keys[0]), (1,))
        self.assertEqual(tuple(descriptor.keys[1]), (8,))

        H_block = descriptor.block(species_center=1)
        self.assertEqual(H_block.values.shape, (2, 2))
        self.assertTrue(np.all(H_block.values[0] == (2, 1)))
        self.assertTrue(np.all(H_block.values[1] == (3, 3)))

        self.assertEqual(len(H_block.samples), 2)
        self.assertEqual(H_block.samples.names, ("structure", "center"))
        self.assertEqual(tuple(H_block.samples[0]), (0, 0))
        self.assertEqual(tuple(H_block.samples[1]), (0, 1))

        self.assertEqual(len(H_block.components), 0)

        self.assertEqual(len(H_block.properties), 2)
        self.assertEqual(H_block.properties.names, ("index_delta", "x_y_z"))
        self.assertEqual(tuple(H_block.properties[0]), (1, 0))
        self.assertEqual(tuple(H_block.properties[1]), (0, 1))

        gradient = H_block.gradient("positions")
        self.assertEqual(gradient.data.shape, (5, 3, 2))
        for i in range(gradient.data.shape[0]):
            self.assertTrue(np.all(gradient.data[i, 0, :] == (0, 1)))
            self.assertTrue(np.all(gradient.data[i, 1, :] == (0, 1)))
            self.assertTrue(np.all(gradient.data[i, 2, :] == (0, 1)))

        self.assertEqual(len(gradient.samples), 5)
        self.assertEqual(gradient.samples.names, ("sample", "structure", "atom"))
        self.assertEqual(tuple(gradient.samples[0]), (0, 0, 0))
        self.assertEqual(tuple(gradient.samples[1]), (0, 0, 1))
        self.assertEqual(tuple(gradient.samples[2]), (1, 0, 0))
        self.assertEqual(tuple(gradient.samples[3]), (1, 0, 1))
        self.assertEqual(tuple(gradient.samples[4]), (1, 0, 2))

        self.assertEqual(len(gradient.components), 1)
        component = gradient.components[0]
        self.assertEqual(len(component), 3)
        self.assertEqual(component.names, ("gradient_direction",))
        self.assertEqual(tuple(component[0]), (0,))
        self.assertEqual(tuple(component[1]), (1,))
        self.assertEqual(tuple(component[2]), (2,))

        self.assertEqual(len(gradient.properties), 2)
        self.assertEqual(gradient.properties.names, ("index_delta", "x_y_z"))
        self.assertEqual(tuple(gradient.properties[0]), (1, 0))
        self.assertEqual(tuple(gradient.properties[1]), (0, 1))

        O_block = descriptor.block(species_center=8)
        self.assertEqual(H_block.values.shape, (2, 2))
        self.assertTrue(np.all(O_block.values[0] == (4, 6)))
        self.assertTrue(np.all(O_block.values[1] == (5, 5)))

    def test_compute_multiple_systems(self):
        systems = [TestSystem(), TestSystem(), TestSystem()]
        calculator = DummyCalculator(cutoff=3.2, delta=2, name="", gradients=True)
        descriptor = calculator.compute(systems, use_native_system=False)

        H_block = descriptor.block(species_center=1)
        self.assertEqual(H_block.values.shape, (6, 2))
        expected = np.array([(0, 0), (0, 1), (1, 0), (1, 1), (2, 0), (2, 1)])
        self.assertTrue(
            np.all(H_block.samples.view(np.int32).reshape(6, 2) == expected)
        )

        O_block = descriptor.block(species_center=8)
        self.assertEqual(O_block.values.shape, (6, 2))

    def test_compute_partial_samples(self):
        system = TestSystem()
        calculator = DummyCalculator(cutoff=3.2, delta=2, name="", gradients=True)

        # Manually constructing the selected samples
        selected_samples = Labels(
            names=["structure", "center"],
            values=np.array([(0, 0), (0, 3), (0, 1)], dtype=np.int32),
        )
        descriptor = calculator.compute(
            system, use_native_system=False, selected_samples=selected_samples
        )

        values = descriptor.block(species_center=1).values
        self.assertEqual(values.shape, (2, 2))
        self.assertTrue(np.all(values[0] == (2, 1)))
        self.assertTrue(np.all(values[1] == (3, 3)))

        values = descriptor.block(species_center=8).values
        self.assertEqual(values.shape, (1, 2))
        self.assertTrue(np.all(values[0] == (5, 5)))

        # Only a subset of the variables defined
        selected_samples = Labels(
            names=["center"],
            values=np.array([0, 3, 1], dtype=np.int32).reshape(3, 1),
        )
        descriptor = calculator.compute(
            system, use_native_system=False, selected_samples=selected_samples
        )

        values = descriptor.block(species_center=1).values
        self.assertEqual(values.shape, (2, 2))
        self.assertTrue(np.all(values[0] == (2, 1)))
        self.assertTrue(np.all(values[1] == (3, 3)))

        values = descriptor.block(species_center=8).values
        self.assertEqual(values.shape, (1, 2))
        self.assertTrue(np.all(values[0] == (5, 5)))

        # empty selected samples
        selected_samples = Labels(
            names=["center"],
            values=np.empty((0, 1), dtype=np.int32),
        )
        descriptor = calculator.compute(
            system, use_native_system=False, selected_samples=selected_samples
        )

        values = descriptor.block(species_center=1).values
        self.assertEqual(values.shape, (0, 2))

        values = descriptor.block(species_center=8).values
        self.assertEqual(values.shape, (0, 2))

    def test_compute_partial_samples_errors(self):
        system = TestSystem()
        calculator = DummyCalculator(cutoff=3.2, delta=2, name="", gradients=True)

        samples = Labels(
            names=["bad name"],
            values=np.array([0, 3, 1], dtype=np.int32).reshape(3, 1),
        )

        with self.assertRaises(RascalError) as cm:
            calculator.compute(
                system, use_native_system=False, selected_samples=samples
            )

        self.assertEqual(
            str(cm.exception),
            "internal error: all labels names must be valid identifiers, 'bad name' is not",
        )

        samples = Labels(
            names=["bad_name"],
            values=np.array([0, 3, 1], dtype=np.int32).reshape(3, 1),
        )

        with self.assertRaises(RascalError) as cm:
            calculator.compute(
                system, use_native_system=False, selected_samples=samples
            )

        self.assertEqual(
            str(cm.exception),
            "invalid parameter: 'bad_name' in samples selection is not one "
            "of the samples of this calculator",
        )

    # def test_compute_partial_features(self):
    #     system = TestSystem()
    #     calculator = DummyCalculator(cutoff=3.2, delta=2, name="", gradients=True)
    #     descriptor = calculator.compute(system, use_native_system=False)

    #     # From a selection scheme, using numpy array indexing
    #     features = descriptor.features[[1]]
    #     descriptor = calculator.compute(
    #         system, use_native_system=False, selected_features=features
    #     )

    #     values = descriptor.values
    #     self.assertEqual(values.shape, (4, 1))
    #     self.assertTrue(np.all(values[0] == [1]))
    #     self.assertTrue(np.all(values[1] == [3]))
    #     self.assertTrue(np.all(values[2] == [6]))
    #     self.assertTrue(np.all(values[3] == [5]))

    #     gradients = descriptor.gradients
    #     self.assertEqual(gradients.shape, (18, 1))
    #     for i in range(gradients.shape[0]):
    #         self.assertTrue(np.all(gradients[i] == [1]))

    #     # Manually constructing the selected features
    #     features = Indexes(
    #         array=np.array([[1, 0]], dtype=np.int32),
    #         names=["index_delta", "x_y_z"],
    #     )
    #     descriptor = calculator.compute(
    #         system, use_native_system=False, selected_features=features
    #     )

    #     values = descriptor.values
    #     self.assertEqual(values.shape, (4, 1))
    #     self.assertTrue(np.all(values[0] == [2]))
    #     self.assertTrue(np.all(values[1] == [3]))
    #     self.assertTrue(np.all(values[2] == [4]))
    #     self.assertTrue(np.all(values[3] == [5]))

    #     gradients = descriptor.gradients
    #     self.assertEqual(gradients.shape, (18, 1))
    #     for i in range(gradients.shape[0]):
    #         self.assertTrue(np.all(gradients[i] == [0]))

    #     # Only a subset of the variables defined
    #     features = Indexes(
    #         array=np.array([1], dtype=np.int32).reshape(1, 1),
    #         names=["index_delta"],
    #     )
    #     descriptor = calculator.compute(
    #         system, use_native_system=False, selected_features=features
    #     )

    #     values = descriptor.values
    #     self.assertEqual(values.shape, (4, 1))

    #     # empty selected features
    #     features = Indexes(
    #         array=np.array([], dtype=np.int32).reshape(0, 2),
    #         names=["index_delta", "x_y_z"],
    #     )
    #     descriptor = calculator.compute(
    #         system, use_native_system=False, selected_features=features
    #     )

    #     values = descriptor.values
    #     self.assertEqual(values.shape, (4, 0))

    # def test_compute_partial_features_errors(self):
    #     system = TestSystem()
    #     calculator = DummyCalculator(cutoff=3.2, delta=2, name="", gradients=True)

    #     features = Indexes(
    #         array=np.array([0, 3, 1], dtype=np.int32).reshape(3, 1),
    #         names=["bad name"],
    #     )

    #     with self.assertRaises(RascalError) as cm:
    #         calculator.compute(
    #             system, use_native_system=False, selected_features=features
    #         )

    #     self.assertEqual(
    #         str(cm.exception),
    #         "invalid parameter: got an invalid column name ('bad name') in "
    #         "selected indexes",
    #     )

    #     features = Indexes(
    #         array=np.array([0, 3, 1], dtype=np.int32).reshape(3, 1),
    #         names=["bad_name"],
    #     )

    #     with self.assertRaises(RascalError) as cm:
    #         calculator.compute(
    #             system, use_native_system=False, selected_features=features
    #         )

    #     self.assertEqual(
    #         str(cm.exception),
    #         "invalid parameter: 'bad_name' in requested features is not part "
    #         "of the features of this calculator",
    #     )

    # def test_features_count(self):
    #     calculator = DummyCalculator(cutoff=3.2, delta=2, name="", gradients=True)
    #     self.assertEqual(calculator.features_count(), 2)


class TestSortedDistances(unittest.TestCase):
    def test_name(self):
        calculator = SortedDistances(
            cutoff=3.5, max_neighbors=12, separate_neighbor_species=False
        )
        self.assertEqual(calculator.name, "sorted distances vector")
        self.assertEqual(calculator.c_name, "sorted_distances")

    def test_parameters(self):
        calculator = SortedDistances(
            cutoff=3.5, max_neighbors=12, separate_neighbor_species=False
        )
        self.assertEqual(
            calculator.parameters,
            """{"cutoff": 3.5, "max_neighbors": 12, "separate_neighbor_species": false}""",
        )


if __name__ == "__main__":
    unittest.main()
