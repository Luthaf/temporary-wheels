# Rascaline

[![Test](https://github.com/Luthaf/rascaline/actions/workflows/tests.yml/badge.svg)](https://github.com/Luthaf/rascaline/actions/workflows/tests.yml)
[![Documentation](https://img.shields.io/badge/documentation-latest-sucess)](https://luthaf.fr/rascaline/index.html)

WIP, please don't use for anything important. Have a look at [the
documentation](https://luthaf.fr/rascaline/index.html) if you want to find out
more.
