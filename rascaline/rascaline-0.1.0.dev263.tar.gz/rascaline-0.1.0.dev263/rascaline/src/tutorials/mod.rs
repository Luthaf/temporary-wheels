/// The code in this module is only built in test mode, to check the code used
/// as example in the tutorials.
///
/// It is part of the main crate instead of being a separate test to allow the
/// tutorial code to use the same import path and testing facilities as the real
/// code.

mod moments;
